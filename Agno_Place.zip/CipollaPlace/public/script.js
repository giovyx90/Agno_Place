const socket = io(); // Connect to the Socket.io server
const grid = document.getElementById("grid");
const infoButton = document.getElementById("info-button");
const infoPopup = document.getElementById("info-popup");
const colorPalette = document.getElementById("color-palette");
const closeButton = document.getElementById("close-info");
const colors = ["red", "blue", "green", "yellow", "orange", "purple", "pink", "brown", "black", "white"];
let selectedColor = null;

    // Function to set a pixel color
    function setPixel(x, y, color) {
      const index = y * 200 + x;
      const cell = grid.children[index];
      cell.style.backgroundColor = color;
      cell.style.opacity = "1";
    }
  
    // Function to fetch and display all pixels from the server
    function fetchAndDisplayPixels() {
      fetch("/pixels")
        .then((response) => response.json())
        .then((pixels) => {
          for (const key in pixels) {
            if (pixels.hasOwnProperty(key)) {
              const [x, y] = key.split(":").map(Number);
              const color = pixels[key];
              setPixel(x, y, color);
            }
          }
        })
        .catch((error) => {
          console.error("Error retrieving pixels:", error);
        });
    }
    
  
    // Creating the 200x200 grid
    for (let y = 0; y < 200; y++) {
      for (let x = 0; x < 200; x++) {
        const cell = document.createElement("div");
        grid.appendChild(cell);
  
        cell.addEventListener("click", () => {
          if (selectedColor) {
            setPixel(x, y, selectedColor);
            socket.emit('pixel', { x, y, color: selectedColor }); // Emit the pixel event to the server
          }
        });
      }
    }
  
    // Listen for pixel events from the server
    socket.on('pixelChange', (data) => {
      const { x, y, color } = data;
      setPixel(x, y, color);
    });
  
    // Creating the color palette
    colors.forEach((color) => {
      const colorDiv = document.createElement("div");
      colorDiv.style.backgroundColor = color;
      colorDiv.addEventListener("click", () => {
        selectedColor = color;
      });
      colorPalette.appendChild(colorDiv);
    });
  
    // Info button click event to show the popup and color palette
    infoButton.addEventListener("click", () => {
      infoPopup.classList.remove("hidden");
      colorPalette.classList.remove("hidden"); // Show color palette
    });
  
    // Close button click event to hide the popup and color palette
    closeButton.addEventListener("click", () => {
      infoPopup.classList.add("hidden");
      colorPalette.classList.add("hidden"); // Hide color palette
    });
  
    // Zoom functionality (applied only to the grid element)
    const zoomSlider = document.getElementById("zoom-slider");
    zoomSlider.addEventListener("input", () => {
      const zoomLevel = zoomSlider.value;
      grid.style.transform = `scale(${zoomLevel})`;
    });
  
    // Listen for pixel events from the server
socket.on('pixelChange', (data) => {
  const { x, y, color } = data;
  console.log(`Received pixel change at ${x}:${y} with color ${color}`);
  setPixel(x, y, color);
});

fetchAndDisplayPixels();

    
  
document.addEventListener("keydown", (event) => {
  // Check if zoomed in
  if (zoomSlider.value > 1) {
    let translationX = parseFloat(grid.style.getPropertyValue('--tx') || 0);
    let translationY = parseFloat(grid.style.getPropertyValue('--ty') || 0);
    const moveAmount = 10; // Amount to move in pixels

    // Check the pressed key and move accordingly
    switch (event.key) {
      case "ArrowLeft":
        translationX += moveAmount;
        break;
      case "ArrowRight":
        translationX -= moveAmount;
        break;
      case "ArrowUp":
        translationY += moveAmount;
        break;
      case "ArrowDown":
        translationY -= moveAmount;
        break;
    }

    // Update CSS variables for translation
    grid.style.setProperty('--tx', `${translationX}px`);
    grid.style.setProperty('--ty', `${translationY}px`);
    grid.style.transform = `scale(${zoomSlider.value}) translate(${translationX}px, ${translationY}px)`;
    event.preventDefault(); // Prevent any default behavior for arrow keys
  }
});
